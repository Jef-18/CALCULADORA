﻿namespace Desafio___Calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtLimpar = new System.Windows.Forms.Button();
            this.txtDiv = new System.Windows.Forms.Button();
            this.txtMult = new System.Windows.Forms.Button();
            this.txtSub = new System.Windows.Forms.Button();
            this.txtADI = new System.Windows.Forms.Button();
            this.txttitulo = new System.Windows.Forms.Label();
            this.txtexit = new System.Windows.Forms.Button();
            this.txtValor1 = new System.Windows.Forms.Label();
            this.txtValor2 = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNum1
            // 
            this.txtNum1.AccessibleName = "";
            this.txtNum1.ForeColor = System.Drawing.Color.Gray;
            this.txtNum1.Location = new System.Drawing.Point(99, 68);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(164, 20);
            this.txtNum1.TabIndex = 0;
            // 
            // txtNum2
            // 
            this.txtNum2.AccessibleName = "";
            this.txtNum2.ForeColor = System.Drawing.Color.Gray;
            this.txtNum2.Location = new System.Drawing.Point(99, 108);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(164, 20);
            this.txtNum2.TabIndex = 1;
            // 
            // txtTotal
            // 
            this.txtTotal.AccessibleName = "";
            this.txtTotal.ForeColor = System.Drawing.Color.Gray;
            this.txtTotal.Location = new System.Drawing.Point(99, 146);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(164, 20);
            this.txtTotal.TabIndex = 2;
            // 
            // txtLimpar
            // 
            this.txtLimpar.Location = new System.Drawing.Point(154, 201);
            this.txtLimpar.Name = "txtLimpar";
            this.txtLimpar.Size = new System.Drawing.Size(75, 43);
            this.txtLimpar.TabIndex = 3;
            this.txtLimpar.Text = "DELETE";
            this.txtLimpar.UseVisualStyleBackColor = true;
            this.txtLimpar.Click += new System.EventHandler(this.txtLimpar_Click);
            // 
            // txtDiv
            // 
            this.txtDiv.Location = new System.Drawing.Point(45, 270);
            this.txtDiv.Name = "txtDiv";
            this.txtDiv.Size = new System.Drawing.Size(75, 43);
            this.txtDiv.TabIndex = 4;
            this.txtDiv.Text = "DIV /";
            this.txtDiv.UseVisualStyleBackColor = true;
            this.txtDiv.Click += new System.EventHandler(this.txtDiv_Click);
            // 
            // txtMult
            // 
            this.txtMult.Location = new System.Drawing.Point(154, 270);
            this.txtMult.Name = "txtMult";
            this.txtMult.Size = new System.Drawing.Size(75, 43);
            this.txtMult.TabIndex = 5;
            this.txtMult.Text = "MULT *";
            this.txtMult.UseVisualStyleBackColor = true;
            this.txtMult.Click += new System.EventHandler(this.txtMult_Click);
            // 
            // txtSub
            // 
            this.txtSub.Location = new System.Drawing.Point(45, 345);
            this.txtSub.Name = "txtSub";
            this.txtSub.Size = new System.Drawing.Size(75, 43);
            this.txtSub.TabIndex = 6;
            this.txtSub.Text = "SUB -";
            this.txtSub.UseVisualStyleBackColor = true;
            this.txtSub.Click += new System.EventHandler(this.txtSub_Click);
            // 
            // txtADI
            // 
            this.txtADI.Location = new System.Drawing.Point(154, 345);
            this.txtADI.Name = "txtADI";
            this.txtADI.Size = new System.Drawing.Size(75, 43);
            this.txtADI.TabIndex = 7;
            this.txtADI.Text = "ADI +";
            this.txtADI.UseVisualStyleBackColor = true;
            this.txtADI.Click += new System.EventHandler(this.txtADI_Click);
            // 
            // txttitulo
            // 
            this.txttitulo.AutoSize = true;
            this.txttitulo.Font = new System.Drawing.Font("Kuchen Hollow", 39.8F, System.Drawing.FontStyle.Bold);
            this.txttitulo.Location = new System.Drawing.Point(12, 9);
            this.txttitulo.Name = "txttitulo";
            this.txttitulo.Size = new System.Drawing.Size(252, 47);
            this.txttitulo.TabIndex = 8;
            this.txttitulo.Text = "CALCULADORA";
            this.txttitulo.Click += new System.EventHandler(this.txttitulo_Click);
            // 
            // txtexit
            // 
            this.txtexit.Location = new System.Drawing.Point(45, 201);
            this.txtexit.Name = "txtexit";
            this.txtexit.Size = new System.Drawing.Size(75, 43);
            this.txtexit.TabIndex = 9;
            this.txtexit.Text = "EXIT";
            this.txtexit.UseVisualStyleBackColor = true;
            this.txtexit.Click += new System.EventHandler(this.txtexit_Click);
            // 
            // txtValor1
            // 
            this.txtValor1.AutoSize = true;
            this.txtValor1.Location = new System.Drawing.Point(20, 75);
            this.txtValor1.Name = "txtValor1";
            this.txtValor1.Size = new System.Drawing.Size(73, 13);
            this.txtValor1.TabIndex = 10;
            this.txtValor1.Text = "Primeiro valor:";
            // 
            // txtValor2
            // 
            this.txtValor2.AutoSize = true;
            this.txtValor2.Location = new System.Drawing.Point(20, 115);
            this.txtValor2.Name = "txtValor2";
            this.txtValor2.Size = new System.Drawing.Size(79, 13);
            this.txtValor2.TabIndex = 11;
            this.txtValor2.Text = "Segundo valor:";
            // 
            // txtResult
            // 
            this.txtResult.AutoSize = true;
            this.txtResult.Location = new System.Drawing.Point(20, 153);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(58, 13);
            this.txtResult.TabIndex = 12;
            this.txtResult.Text = "Resultado:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 450);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtValor2);
            this.Controls.Add(this.txtValor1);
            this.Controls.Add(this.txtexit);
            this.Controls.Add(this.txttitulo);
            this.Controls.Add(this.txtADI);
            this.Controls.Add(this.txtSub);
            this.Controls.Add(this.txtMult);
            this.Controls.Add(this.txtDiv);
            this.Controls.Add(this.txtLimpar);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Name = "Form1";
            this.Text = "l";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Button txtLimpar;
        private System.Windows.Forms.Button txtDiv;
        private System.Windows.Forms.Button txtMult;
        private System.Windows.Forms.Button txtSub;
        private System.Windows.Forms.Button txtADI;
        private System.Windows.Forms.Label txttitulo;
        private System.Windows.Forms.Button txtexit;
        private System.Windows.Forms.Label txtValor1;
        private System.Windows.Forms.Label txtValor2;
        private System.Windows.Forms.Label txtResult;
    }
}

